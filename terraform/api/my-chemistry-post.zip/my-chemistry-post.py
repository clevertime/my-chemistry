import boto3
import json
import logging
import os

# globals
dynamodb = boto3.resource('dynamodb')

# create record in dynamo
def create_record(table):
    logging.info("[*] posting record to dynamo: " + table)
    try:
        dynamo_table = dynamodb.Table(table)
        dynamo_table.put_item(
            Item={
                'timestamp': "test"
            }
        )
    except:
        logging.error("\n[!] dynamodb table: " + table + " not found")


def handler (event, context):
	create_record(os.environ['TABLE_NAME'], event.data)
	print(event.data)
	return True
